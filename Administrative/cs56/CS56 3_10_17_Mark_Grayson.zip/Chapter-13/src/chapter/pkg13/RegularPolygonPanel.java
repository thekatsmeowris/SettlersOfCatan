/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chapter.pkg13;

/**
 *
 * @author makogenq
 */

import java.awt.*;
import javax.swing.*;
class RegularPolygonPanel extends JPanel
{
    
    public RegularPolygonPanel()
    {
        numberOfSides = 5;
        numberOfPolygons= 6;
    }

    public RegularPolygonPanel(int numberOfSides)
    {
        this.numberOfSides = 3;
        setNumberOfSides(numberOfSides);
    }

    public int getNumberOfSides()
    {
        return numberOfSides;
    }

    public void setNumberOfSides(int numberOfSides)
    {
        this.numberOfSides = numberOfSides;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g)
    {
        super.paintComponent(g);
       //make however many polygons 
        int r = ((getWidth()/numberOfPolygons)/2);
            if(r>(getHeight()/2)){
                r=getHeight()/2;
            }
        int pSpacer=((2*r)/numberOfPolygons);
        r=r-(r/6);
       
       for(int i=1; i< numberOfPolygons+1; i++){
           //make new polygon--
            Polygon p=new Polygon();
            
            System.out.println("width "+getWidth());
            int pXCenter=(int)(((i-1)*2*r)+(r/2)+(i*pSpacer));
            int pYCenter=(int)((getHeight()/2));
            
            System.out.println("px center " +pXCenter);
            System.out.println("py center " +pYCenter);
            System.out.println("radius " +r);

            
           //add the appropriate points
            double angle = 2*Math.PI / numberOfSides;
            System.out.println("number of sides: "+numberOfSides);
            System.out.println("angle: "+angle);

            for(int j = 0; j < numberOfSides; j++){
        
                p.addPoint((int)(pXCenter+((double)r*Math.cos(angle*j))), (int)(pYCenter+((double)r*Math.sin(angle*j))));
                System.out.println("added point: "+ (int)(pXCenter+((double)r*Math.cos(angle*j)))+" "+ (int)(pYCenter-((double)r*Math.sin(angle*j))));
   
            }
            g.drawPolygon(p);
            numberOfSides++;
            
       

        }
       numberOfSides=5;
    }

    @Override
    public Dimension getPreferredSize()
    {
        return new Dimension(600, 200);
    }

    private int numberOfSides;
    private int numberOfPolygons;
}