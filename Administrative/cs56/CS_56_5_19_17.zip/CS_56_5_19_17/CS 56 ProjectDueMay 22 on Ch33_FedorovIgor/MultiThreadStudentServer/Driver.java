/*
 * Section: CS56F @ SMC
 * Name: Fedorov Igor
 * Date: 05/18/2015
 * Assignment: CS 56 ProjectDueMay 22 on Ch33 (9e)
 */

import java.io.FileInputStream;
import java.io.ObjectInputStream;

public class Driver {

	static ObjectInputStream in;

	public static void main(String[] args) throws Exception {
		Student st;

		try {
			in = new ObjectInputStream(new FileInputStream("student.dat"));
			while (true) {
				st = (Student) in.readObject();
				System.out.println("=====>>>>>" + st.getName());
				System.out.println("=====>>>>>" + st.getStreet());
				System.out.println("=====>>>>>" + st.getCity());
				System.out.println("=====>>>>>" + st.getState());
				System.out.println("=====>>>>>" + st.getZip());
				System.out.println("=========================");
			}
		} catch (Exception e) {
			in.close();
		}

	}

}