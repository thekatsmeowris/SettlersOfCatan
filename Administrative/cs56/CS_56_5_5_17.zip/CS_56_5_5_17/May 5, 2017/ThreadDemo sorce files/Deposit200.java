
public class Deposit200 implements Runnable {
	Account a = Account.getAccount();
	@Override
	public void run() {
		try {
		    for (int i = 0; i < 200; i++) {
			       a.deposit(1);
			
				Thread.sleep(1);
				}
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

