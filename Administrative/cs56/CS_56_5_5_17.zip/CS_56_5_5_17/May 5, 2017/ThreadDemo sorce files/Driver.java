import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.swing.JOptionPane;


public class Driver {
	public static void main(String[] args) {
		Thread task = new Thread(new Deposit100());
		Thread task1 = new Thread(new Deposit100());
		Thread task2 = new Thread(new Withdrawer());
		Thread task3 = new Thread(new Withdrawer());
		
		task.start();
		task1.start();
		task2.start();
		task3.start();
		while((task.getState() != 
		Thread.State.TERMINATED)
			|| (task1.getState()
			!= Thread.State.TERMINATED)) {
			
		}
		Account a = Account.getAccount();
		System.out.println("The balance is -->> " + a.getBalance());
	}
}







/*
ExecutorService ex = Executors.newFixedThreadPool(2);
ex.execute(new Deposit100());
ex.execute(new Deposit200());
ex.shutdown();
while (!ex.isTerminated()) {
	
	
}
while((task.getState() != Thread.State.TERMINATED) || (task1.getState() != Thread.State.TERMINATED)) {
	
} */

//JOptionPane.showMessageDialog(null, "Waiting");
