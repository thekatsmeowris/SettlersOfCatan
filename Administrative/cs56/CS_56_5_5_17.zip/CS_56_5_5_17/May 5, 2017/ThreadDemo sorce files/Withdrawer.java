
public class Withdrawer implements Runnable {
	Account a = Account.getAccount();
	@Override
	public void run() {
		try {
			while(true) {
				a.withdraw( (int)(Math.random() * 1000));
				Thread.sleep(10);
			}
		} catch (Exception e) {
			
		}
		
		
	}

}
