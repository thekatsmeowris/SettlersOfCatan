//  class MyRect.java
//
//  RectPanelTest.java
//
//  Robert Turkel, #284282
//  CS 56, Homework 
//  3/4/2004
//
//  Purpose:
//      Create a reusable, self contained class (RectPanel)
//      Class is to accept mouse click or 
//          position entry in text fields and Enter clicked.
//      Class "moves" a randomly colored fixed size rectangle 
//          so upper left corner is where mouse was clicked,
//          or is at the entered coordinates (in pixels).
//      In addition, when mouse is clicked the text fields
//          are to display the coordintes of the location clicked.
//      Next, expand MyRect.java to include additional methods.
//      Then, create a program to test the various features
//      of the class.
//
//      This is an expansion of the provided MyRect.java class.
//
//  Java packages
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class MyRect {

///////////Provided constructors and methods

	private int height, width;
	private int xpos=20, ypos=20;

	public MyRect( ){ }

	public MyRect( int h, int w ){
		height = h;
		width = w;
	}

	public void setLocation ( int x, int y ){
		xpos = x;
		ypos = y;
	}

	public void draw ( Graphics g ){
		g.drawRect ( xpos, ypos, width, height );
	}

	public void fill ( Graphics g ){
		g.fillRect ( xpos, ypos, width, height );
	}
	
	//more methods� set, get, area, perimeter, etc.
///////////End of provided constructors and methods
	//
	//
	//	Additional methods
	//
	//
	//  sets
	//  converting any negative dimension 
	//  or coordinate to positive
	public void setHeight( int h ) { Math.abs(height = h); }
	public void setWidth( int w ) { Math.abs(width = w); }
	public void setX( int x ) { Math.abs(xpos = x); }
	public void setY( int y ) { Math.abs(ypos = y); }
	//
	//  gets
	public int getHeight( ) { return height; }
	public int getWidth( ) { return width; }
	public int getX( ) { return xpos; }
	public int getY( ) { return ypos; }
	//
	//  area
	public int getArea() { 
	  return height * width; 
	}
	//
	// perimeter
	public int getPerimeter() { 
	  return 2 * ( height + width ); 
	}
	//
	// diagonal
	public int getDiagonalLength() { 
	    return (int)Math.sqrt(height * height + width * width); 
	}
	//
	//  toString
	public String toString() { return (
			"Location = (" + Integer.toString(getX()) 
			+ ", " + Integer.toString(getY()) + ")"
			+ "\nHeight = " + height
			+ "\nWidth = " + width );}
	//
	//
}
