//  class RectPanel.java
//
//  RectPanelTest.java
//
//  Robert Turkel, #284282
//  CS 56, Homework 
//  3/4/2004
//
//  Purpose:
//      Create a reusable, self contained class (RectPanel)
//      Class is to accept mouse click or 
//          position entry in text fields and Enter clicked.
//      Class "moves" a randomly colored fixed size rectangle 
//          so upper left corner is where mouse was clicked,
//          or is at the entered coordinates (in pixels).
//      In addition, when mouse is clicked the text fields
//          are to display the coordintes of the location clicked.
//      Next, expand MyRect.java to include additional methods.
//      Then, create a program to test the various features
//      of the class.
//
//      This is the class for RectPanel.
//
//  Java packages
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
//
public class RectPanel extends JPanel implements 
    MouseListener, ActionListener, FocusListener {
//
//  some variables
    private MyRect box;
    private BorderLayout bl;
    private JTextField tX, tY;
    private int width;
    private int height;
    private int heightLower = 35;
    private int heightUpper;
//
//  default constructor, arbitrarily sized for 800 * 600 frame
    public RectPanel() {
        width = 790;
        height = 565;
        RestOfConstructor();
    }
//
//  constructor which can create different size RectPanels
    public RectPanel(int w, int h) {
        width = w;
        height = h;
        RestOfConstructor();
    }
//
//  I didn't want to duplicate a lot of code
    private void RestOfConstructor() {
        //
        //  enlarged rectangle from original
        box = new MyRect(50,100);
        //
        //  sort of define the bare RectPanel
        heightUpper = height - heightLower;
        bl = new BorderLayout();
        setPreferredSize(new Dimension(width, height));
        setLayout(bl);
        setBorder(BorderFactory.createLineBorder(Color.BLACK));
        setBackground(Color.WHITE);
        //
        //  set up panel with text fields
        JPanel pLower = new JPanel();
        pLower.setPreferredSize(new Dimension(width, heightLower));
        pLower.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        pLower.setBackground(Color.BLUE);
        pLower.setLayout(new FlowLayout());
        //
        //  instruct the user
        JLabel l1 = new JLabel("Click mouse or set (x,y) 0 <= x <= " 
            + Integer.toString(width) + ", 0 <= y <= " 
            + Integer.toString(height-heightLower) 
            + " and press Enter.  x=");
        l1.setForeground(Color.ORANGE);
        pLower.add(l1);
        //
        //  set up X text field
        tX = new JTextField("20",4);
        tX.addActionListener(this);
        tX.addFocusListener(this);
        pLower.add(tX);
        //
        //  set up label for second text field
        JLabel l2 = new JLabel("  y=");
        l2.setForeground(Color.ORANGE);
        pLower.add(l2);
        //
        //  set up Y text field
        tY = new JTextField("20",4);
        tY.addActionListener(this);
        tY.addFocusListener(this);
        pLower.add(tY);
        //
        //  add 'control' panel to bottom of RectPanel
        add(pLower, BorderLayout.SOUTH);
        addMouseListener(this);
    }
//
    public void paintComponent ( Graphics g ){
        super.paintComponent( g );
        //
    	//randomly change color of rect everytime
        g.setColor ( new Color ((int)(Math.random( ) * 256 ),
                                (int)(Math.random( ) * 256 ), 
                                (int)(Math.random( ) * 256 ) ));
        box.fill( g );
    }
//
////////private class moves rectangle, if valid location,
////////and tells mouse handler whether it was moved.
////////keeps consistent results for click and coords
    private boolean moveToValidLocation( int x, int y ) {
        //
        // the maximum acceptible here will put the
        // rectangle at the lower right 
        // corner of the JPanel
        if( (x>=0)&&
            (x<=width)&&
            (y>=0)&&
            (y<=heightUpper) ) {
            //
            //  move the rectangle's location
            box.setLocation(x,y);
            //
            //  show RectPanel as it now is 
            //      (also sets random color)
            repaint();
            //
            //  tell that we moved it
            return true;
        }
        //
        //  tell that we didn't move it
        else return false;
    }
//
////////private class implements MouseListener
    public void mousePressed ( MouseEvent e ){
        //
        //  get the x & y coordinates where mouse was clicked
        int x = e.getX( );
        int y = e.getY( );
        //
        //  move rectangle and display 
        //      location in JTextFields,
        //      if clicked in display area
        if( moveToValidLocation( x, y ) ) {
            tX.setText(Integer.toString(x));
            tY.setText(Integer.toString(y));
        }
    }
//
//  unneeded mouse events
    public void mouseExited ( MouseEvent e ){ }
    public void mouseEntered ( MouseEvent e ){ }
    public void mouseReleased ( MouseEvent e ){ }
    public void mouseClicked ( MouseEvent e ){ }
//
////////private class implements ActionListener
    public void actionPerformed(ActionEvent ae) {
        String sX = tX.getText();
        String sY = tY.getText();
        //
        // a little error and limit checking
        try {
            int x = Integer.parseInt(sX);
            int y = Integer.parseInt(sY);
            //
            // move rectangle if coordinates are valid
            // we aren't using return value, but could
            //     if we wanted to display a message
            moveToValidLocation( x, y );
        }
        // give message, if an integer was not entered
        catch(NumberFormatException nfe) {
            JOptionPane.showMessageDialog(null, 
                "Your coordinates: (" + sX + ", " + sY + 
                ") must both be integers.", 
                "Invalid Location", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
//
////////private class implements FocusListener
//
//  some user may like to have the contents of a JTextField,
//      selected on entry, for entirely changing a value    
    public void focusGained(FocusEvent fe) {
    	if(fe.getSource()==tX){
    		tX.selectAll();
    	}
    	else {
    		tY.selectAll();
    	}
    }
    
    public void focusLost(FocusEvent fe) {}

}