/*
 * Section: CS56F @ SMC
 * Name: Fedorov Igor
 * Date: 05/18/2015
 * Assignment: CS 56 ProjectDueMay 22 on Ch33 (9e)
 */

public class Student implements java.io.Serializable {
 
private String name;
  private String street;
  private String city;
  private String state;
  private String zip; 
  
  public Student(String name, String street, String city,
    String state, String zip) {
    this.name = name;
    this.street = street;
    this.city = city;
    this.state = state;
    this.zip = zip;
  }
  
  public String getName() {
    return name;
  }
  
  public String getStreet() {
    return street;
  }
  
  public String getCity() {
    return city;
  }
  
  public String getState() {
    return state;
  }
  
  public String getZip() {
    return zip;
  }
}

