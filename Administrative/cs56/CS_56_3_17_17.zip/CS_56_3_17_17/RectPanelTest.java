//  class RectPanelTest.java
//
//  RectPanelTest.java
//
//  Robert Turkel, #284282
//  CS 56, Homework 
//  3/4/2004
//
//  Purpose:
//      Create a reusable, self contained class (RectPanel)
//      Class is to accept mouse click or 
//          position entry in text fields and Enter clicked.
//      Class "moves" a randomly colored fixed size rectangle 
//          so upper left corner is where mouse was clicked,
//          or is at the entered coordinates (in pixels).
//      In addition, when mouse is clicked the text fields
//          are to display the coordintes of the location clicked.
//      Next, expand MyRect.java to include additional methods.
//      Then, create a program to test the various features
//      of the class.
//
//      This is a fairly minimalist test driver for RectPanel.
//
//  Java packages
import java.awt.*;
import javax.swing.*;

public class RectPanelTest {
//
    public static void main( String [] args){
        //
        //  set up a frame
        JFrame win= new JFrame ("Moving Rectangle");
        //
        //  create a RectPanel
        RectPanel  rp = new RectPanel();
        //
        //  put it in/on the frame
        win.setContentPane(rp);
        //
        //  set the frame to a good size
        win.setSize(800, 600);
        //
        //  that's pretty much it
        win.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        win.setVisible(true);
     }
}
       