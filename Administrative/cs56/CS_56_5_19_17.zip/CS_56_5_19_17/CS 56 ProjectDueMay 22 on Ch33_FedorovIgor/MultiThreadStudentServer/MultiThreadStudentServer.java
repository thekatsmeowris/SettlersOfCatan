/*
 * Section: CS56F @ SMC
 * Name: Fedorov Igor
 * Date: 05/18/2015
 * Assignment: CS 56 ProjectDueMay 22 on Ch33 (9e)
 */

import java.io.*;
import java.net.*;
import java.util.*;
import java.awt.*;

import javax.swing.*;
import javax.swing.text.DefaultCaret;

public class MultiThreadStudentServer extends JFrame {
	// Text area for displaying contents
	private JTextArea jta = new JTextArea();

	public static void main(String[] args) {
		new MultiThreadStudentServer();
	}

	public MultiThreadStudentServer() {

		// Place text area on the frame
		setLayout(new BorderLayout());
		add(new JScrollPane(jta), BorderLayout.CENTER);

		// Scroll down JTextArea jta automatically, after each append.
		DefaultCaret caret = (DefaultCaret) jta.getCaret();
		caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);

		setTitle("MultiThreadStudentServer");
		setSize(500, 300);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true); // It is necessary to show the frame here!

		try {
			// Create a server socket
			ServerSocket serverSocket = new ServerSocket(8000);
			System.out.println("Server started ");			
			jta.append("MultiThreadServer started at " + new Date() + '\n');

			// Number a client
			int clientNo = 1;

			while (true) {
				
				// Listen for a new connection request
				Socket socket = serverSocket.accept();
				
				// Display the client number
				jta.append("Starting thread for client " + clientNo + " at "
						+ new Date() + '\n');

				// Find the client's host name, and IP address
				InetAddress inetAddress = socket.getInetAddress();
				jta.append("Client " + clientNo + "'s host name is "
						+ inetAddress.getHostName() + "\n");
				jta.append("Client " + clientNo + "'s IP Address is "
						+ inetAddress.getHostAddress() + "\n");

				// Create a new thread for the connection
				HandleAStudentClient task = new HandleAStudentClient(socket);

				// Start the new thread
				new Thread(task).start();

				// Increment clientNo
				clientNo++;
			}

		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}

	// Inner class
	// Define the thread class for handling new connection
	class HandleAStudentClient implements Runnable {

		private Socket socket; // A connected socket
		
		/** Construct a thread */
		public HandleAStudentClient(Socket socket) {
			this.socket = socket;
		}

		/** Run a thread */
		public void run() {
			try {
				// Create an object input and output streams
				ObjectInputStream inputFromClient = new ObjectInputStream(
						socket.getInputStream());

				File output = new File("student.dat");
				ObjectOutputStream outputToFile;

				// Original peace of the code
				// Create an object ouput stream
				// outputToFile = new ObjectOutputStream(new
				// FileOutputStream(output, true));

				/*
				 * Check whether the "student.dat" file exists or not and 
				 * instantiate either this appendable stream (in case the 
				 * file exists, append data and do not need a header) or  
				 * the original stream (in case the file does not exist,  
				 * need a header).
				 */
				if (!output.exists()) {
					output.createNewFile();
					outputToFile = new ObjectOutputStream(
							                  new FileOutputStream(output, true));
				} else {
					outputToFile = new AppendingObjectOutputStream(
							                   new FileOutputStream(output, true));
				}

				// Continuously serve the client
				while (true) {
					
					// Read from input
					Object object = inputFromClient.readObject();

					// Write to the file
					outputToFile.writeObject(object);
					System.out.println("A new student object is stored");

					Student st = (Student) object;

					jta.append("information received from client: \n");
					jta.append("Name: " + st.getName() + "\n");
					jta.append("Street Address: " + st.getStreet() + "\n");
					jta.append("City: " + st.getCity() + "\n");
					jta.append("State: " + st.getState() + "\n");
					jta.append("Zip: " + st.getZip() + "\n");
					jta.append("=========================" + "\n");

					outputToFile.close();
				}
			} catch (ClassNotFoundException ex) {
				// ex.printStackTrace();
			} catch (IOException ex) {
				// ex.printStackTrace();
			}
		}

	}
}
