import javax.swing.*;
import java.awt.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.util.*;

public class ShowThreads
{
	public static void main(String [] args)
	{
		PrintA t1 = new PrintA();
		t1.start();
		
		Thread t2 = new Thread(new PrintB());
		t2.start();
		Thread t3 = new Thread(new PrintC());
		t3.start();
		
		JOptionPane.showMessageDialog(null," Please wait....");
		System.exit(0);
	}
	
	
	
	
}

class PrintB implements Runnable
{
	public void run()
	{
		try{
			for( ; ; )
			{
				System.out.print("B");
				Thread.sleep(200);
				
			}
			
			
		}catch( Exception ex)
		{
			
			
		}
		
		
		
		
	}
	
	
	

}
class PrintC implements Runnable
{
	public void run()
	{
		try{
			for( ; ; )
			{
				System.out.print("C");
				Thread.sleep(300);
				
			}
			
			
		}catch( Exception ex)
		{
			
			
		}
		
		
		
		
	}
	
	
	

}






class PrintA extends Thread
{
	public void run()
	{
		try{
			for( ; ;)
			{
				System.out.print("A");
				Thread.sleep(100);
				
			}
			
			
		}catch( Exception ex)
		{
			
			
		}
		
		
		
		
	}
	
	
	
	
	
}





