/*
 * Section: CS56F @ SMC
 * Name: Fedorov Igor
 * Date: 05/18/2015
 * Assignment: CS 56 ProjectDueMay 22 on Ch33 (9e)
 */

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

/**
 *  AppendingObjectOutputStream.java
 *
 *
 *  @author Christian Sherland
 *  @author Ethan Lusterman
 *  @author Michael Scibor
 *
 *  @version 1.0 Mar 6 2014
 *  
 *  This class is used in MultiThreadStudentServer (lines 100-119)
 */
public class AppendingObjectOutputStream extends ObjectOutputStream {

	  public AppendingObjectOutputStream(OutputStream out) throws IOException {
	    super(out);
	  }

	  @Override
	  protected void writeStreamHeader() throws IOException {
	    // do not write a header, but reset:
	    // this line added after another question
	    // showed a problem with the original
	    reset();
	  }

	}