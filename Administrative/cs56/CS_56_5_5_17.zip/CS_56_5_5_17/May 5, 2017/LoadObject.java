import java.awt.*; 
import javax.swing.*; 
import java.util.*;
import java.io.*;
 
// ************* 
public class LoadObject
{   
    static ObjectInputStream input;
	
	public static void main(String [] args)
	{
		ArrayList <APerson> m = new <APerson> ArrayList();
		
		
		openFile();
		readRecord(m);
		closeFile();
		
		System.out.println("File is loaded");
		
		for(APerson  a : m)
			System.out.println(a);
		
		
		
	}
	public static void openFile()
	{
		try{
			input = new ObjectInputStream(new FileInputStream("client.ser"));
			
			
		}catch (IOException io)
		{
			System.err.println("Error in loading to File");
			System.exit(1);
			
		}
	}
	
	
	
	
	public static void readRecord(ArrayList <APerson>     r)
	{
		APerson ap = null;
		
		try{
			while(true)
			{
				ap =(APerson)     input.readObject();
				r.add(ap);
			}
			
		}catch (EOFException io)
		{
			
			return ;
		}
		catch (ClassNotFoundException e)
		{
			System.err.println("Unable to create Object");
		}
		catch (IOException ex)
		{
			
		}
	}
	
	
	
	
	public static void  closeFile()
	{
		try{
			if(input != null)
				input.close();
			
		}catch (IOException io)
		{
			System.exit(0);
		}
		
		
		
	}
	
	
}