import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;


// Singelton class
public class Account {
 private double balance;
 private static Account sh = null;
 private Lock myLock = new ReentrantLock();
 private Condition newDeposit = myLock.newCondition();
 
 // note private Constructor
 
	private Account() {
	}
	
	public synchronized static Account getAccount() {
			if (sh == null) {
				sh = new Account();
			}
		return sh;
	}
	public /*synchronized*/ void deposit(double amt) {
		myLock.lock();
		try {
			balance += amt;
			System.out.println("Deposit -> " + amt + " Balance -> " + balance);
			newDeposit.signalAll();
		} catch (Exception e) {
			
		}
		finally {
			myLock.unlock();
		}
	}
	
	public void withdraw(double amt) {
		myLock.lock();
		try {
			while(balance < amt) {
				System.out.println("Waiting for new deposit" + " trying to withdraw " + amt);
				newDeposit.await();
			}
			balance -= amt; 
			System.out.println("I withdrawed " + amt);
		} catch (InterruptedException ex) {
			System.out.println(ex.getMessage());
		}
		finally {
			myLock.unlock();
		}
	}
	
	public double getBalance() {
		return balance;
	}
}
