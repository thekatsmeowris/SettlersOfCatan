
public class Deposit100 implements Runnable {
	Account a = Account.getAccount();
	@Override
	public void run() {
		try {
			while(true) {
				a.deposit(10);
				Thread.sleep(10);
			}
		} catch (Exception e) {
		}
	}
	
}
