import java.awt.*; 
import javax.swing.*; 
import java.util.*;
import java.io.*;
 
// ************* 
public class SaveObject
{   
    static ObjectOutputStream output;
	
	public static void main(String [] args)
	{
		ArrayList <APerson> m = new <APerson> ArrayList();
		APerson p1 = new APerson("Lisa","Smith","111-11-1111",21,"Lisa@heaven.com");
		APerson p2 = new APerson("Jack","Smith","222-11-1111",45,"Jack@heaven.com");
		m.add(p1); m.add(p2);
		for(APerson  a : m)
			System.out.println(a);
		openFile();
		addRecord(m);
		closeFile();
		
		System.out.println("File is saved");
		
		
		
	}
	public static void closeFile()
	{
		try{
			if(output != null)
				output.close();
			
		}catch (IOException io)
		{
			System.err.println("Error in writing to File");
			System.exit(1);
			
		}
	}
	
	
	
	
	public static void addRecord(ArrayList <APerson>     r)
	{
		try{
			for(APerson ap : r)
			output.writeObject(ap);
			
		}catch (IOException io)
		{
			System.out.println("Error found ...");
			return ;
		}
		
		
	}
	
	
	
	
	public static void openFile()
	{
		try{
			output = new ObjectOutputStream(new FileOutputStream("client.ser"));
			
		}catch (IOException io)
		{
			System.out.println("Error found ...");
		}
		
	}
	
	
	
}