/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chapter.pkg13;
import java.awt.*;
import javax.swing.*;
/**
 *
 * @author makogenq
 */
public class Chapter13 {

    private JFrame f;
    private JPanel p;
    private JButton b1;
    private JLabel l;
    
    public Chapter13(){
        //gui();
        polygonPanelGui();
    }
    public void gui(){
        f = new JFrame("Creativity tuts");
        f.setVisible(true);
        f.setSize(600,450);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        p= new JPanel();
        p.setBackground(Color.YELLOW);
        
        b1= new JButton("test");
        l= new JLabel ("this is test label");
        
        p.add(b1);
        p.add(l);
        f.add(p);
    }
    public void polygonPanelGui(){
        JFrame pframe = new JFrame("RegularPolygonPanel");
        pframe.getContentPane().add(new RegularPolygonPanel());
        pframe.setSize(650, 160);
        pframe.pack();
        pframe.setVisible(true);
        pframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        Chapter13 c=new Chapter13();
      
        
    }
    
}
