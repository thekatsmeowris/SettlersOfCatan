import javax.swing.*;
import java.awt.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.util.*;

public class TestAcc 
{   

   public static void main(String[] args)
   {
	   Account ac1 = Account.getAccount();
	   
	   /*Account ac2 = Account.getAccount();
	   ac1.deposit(1000);
	   ac2.deposit(3000);
	   */
	   Thread t1 = new Thread(new Depositor1());
	   Thread t2 = new Thread(new Depositor2());
	   t1.start(); t2.start();
	   while(t1.isAlive() || t2.isAlive())
		   ;
	   
	   System.out.println("Bal is "+ ac1.getBalance());
   }
}
class Depositor1 implements Runnable
{
	
	public void run()
	{
		try{
			for(int i = 1 ; i <=100; i++)
			{
			   Account.getAccount().deposit(1);
			   Thread.sleep(50);
			}
			
		}catch (Exception ex)
		{
			
			
		}
		
		
	}
	
	
	
	
}
class Depositor2 implements Runnable
{
	
	public void run()
	{
		try{
			for(int i = 1 ; i <=100; i++)
			{
			   Account.getAccount().deposit(1);
			   Thread.sleep(30);
			}
			
		}catch (Exception ex)
		{
			
			
		}
		
		
	}
	
	
	
	
}


