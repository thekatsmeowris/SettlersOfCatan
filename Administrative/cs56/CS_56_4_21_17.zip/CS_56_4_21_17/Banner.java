import javax.swing.*;
import java.awt.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.util.*;

public class Banner extends JFrame implements ActionListener
{
	private Container c;
	private JLabel mess = new JLabel();
	private JButton b;
	
	public Banner()
	{
		c = getContentPane();
		
		c.setBackground(Color.BLACK);
		Font f = new Font("Times new Roman",Font.BOLD+Font.ITALIC, 45);
		b = new JButton("Start");
		b.addActionListener(this);
		mess.setFont(f);
		mess.setForeground(Color.YELLOW);
		
		mess.setText("...Hello...From...Jupiter...");
		
		c.setLayout(new BorderLayout());
		c.add(mess, BorderLayout.CENTER);
		c.add(b,BorderLayout.SOUTH);
		
	}
	
    public void doBanner()
	{
		String x = mess.getText();
		char ch = x.charAt(0);
		String rest = x.substring(1);
		String strNew = rest + ch;
		mess.setText(strNew);
		
	}
     public class Worker implements Runnable
	 {
		 public void run()
		 {
			try{
				while(true)
				{
					doBanner();
					Thread.sleep(100);
				}
				
				
			}catch (Exception ex)
			{
				
			}			
			 
			 
		 }
		 
		 
	 }



	
	public void actionPerformed(ActionEvent e)
	{
		Thread t = new Thread(new Worker());
		t.start();
	}	
		
	public static void main(String [] args)
	{
		Banner win = new Banner();
		win.setSize(600,600);
		win.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		win.setVisible(true);
	}
		
		
	}	
		
	
	
	
	
	
	
